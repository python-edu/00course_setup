[
  (block)
  (array)
] @fold
