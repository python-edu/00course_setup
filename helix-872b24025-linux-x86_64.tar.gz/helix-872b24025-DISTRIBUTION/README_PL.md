# Helix — instalacja (Linux x86-64)

1. Rozpakuj pobrane archiwum i przejdź do katalogu:

   ```bash
   tar -xzf helix-872b24025-linux-x86_64.tar.gz
   cd helix-872b24025-DISTRIBUTION
   ```

2. Skopiuj program i konfigurację:

   ```bash
   mkdir -p ~/.local/bin ~/.config/helix
   cp hx ~/.local/bin/hx
   cp -a helix/. ~/.config/helix/
   chmod +x ~/.local/bin/hx
   ```

3. Sprawdź polecenie:

   ```bash
   command -v hx
   ```

   Jeśli nic nie wyświetla (Bash):

   ```bash
   echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
   source ~/.bashrc
   ```

4. Sprawdź instalację:

   ```bash
   hx --version
   hx --health python
   ```

**Uwaga:** kopiowanie `helix/` może zastąpić wcześniejszy `~/.config/helix/config.toml`.
