(braced_word) @fold
